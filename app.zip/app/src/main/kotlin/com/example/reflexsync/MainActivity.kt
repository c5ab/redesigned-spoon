package com.example.reflexsync

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class MainActivity : ComponentActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val logBuf = StringBuilder()
    private lateinit var logView: TextView
    private lateinit var deviceBox: LinearLayout
    private lateinit var uuidIn: EditText
    private lateinit var hexIn: EditText

    private val devices = LinkedHashMap<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var scanning = false
    private val hrSamples = mutableListOf<HeartRateRecord.Sample>()

    private val healthCh = Channel<ByteArray>(Channel.UNLIMITED)
    private val commCh = Channel<ByteArray>(Channel.UNLIMITED)
    private val writeCh = Channel<Int>(Channel.UNLIMITED)
    private var syncing = false

    private val queue = ArrayDeque<() -> Boolean>()
    private var busy = false

    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val btBase = "-0000-1000-8000-00805f9b34fb"
    private val known = mapOf(
        "1800" to "Generic Access", "1801" to "Generic Attribute",
        "180a" to "Device Info", "180d" to "Heart Rate", "180f" to "Battery",
        "2a37" to "HR Measurement", "2a19" to "Battery Level",
        "2a29" to "Manufacturer", "2a24" to "Model", "2a26" to "Firmware",
        "2a27" to "Hardware rev", "2a28" to "Software rev"
    )

    private val hcPerms = setOf(
        HealthPermission.getWritePermission(StepsRecord::class),
        HealthPermission.getWritePermission(HeartRateRecord::class),
        HealthPermission.getWritePermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getWritePermission(SleepSessionRecord::class)
    )

    private val blePermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            log("Bluetooth permissions: $r")
        }

    private val hcLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
            log("Health Connect permissions granted: ${granted.size} of ${hcPerms.size}")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 24)
        }
        root.addView(btn("1. Grant Bluetooth permission") { requestBlePerms() })
        root.addView(btn("2. Grant Health Connect permission") { requestHc() })
        root.addView(btn("3. Scan for watch (15 s)") { startScan() })
        deviceBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceBox)
        root.addView(btn("Disconnect") { disconnect() })
        root.addView(btn("SYNC NOW (steps, calories, heart rate, sleep)") { syncNow() })
        root.addView(btn("Set watch time to phone time") { setWatchTime() })
        root.addView(btn("Sync live heart rate buffer (old)") { syncHr() })
        root.addView(btn("Test Health Connect (writes 10 steps)") { testHc() })
        root.addView(btn("Copy log") { copyLog() })
        uuidIn = EditText(this).apply { hint = "characteristic UUID (full or 4 hex digits)" }
        hexIn = EditText(this).apply { hint = "hex bytes to write, e.g. 01 ff" }
        root.addView(uuidIn)
        root.addView(hexIn)
        root.addView(btn("Write hex to characteristic") { writeHex() })
        logView = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 11f
            typeface = Typeface.MONOSPACE
        }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
        log("Ready. Do steps 1, 2, 3 in order. Close the official Fastrack app first.")
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun log(s: String) {
        ui.post {
            logBuf.append(timeFmt.format(Date())).append("  ").append(s).append('\n')
            if (logBuf.length > 30000) logBuf.delete(0, logBuf.length - 30000)
            logView.text = logBuf.toString()
        }
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()))
        log("Log copied to clipboard")
    }

    private fun hex(b: ByteArray) = b.joinToString(" ") { "%02x".format(it) }

    private fun label(u: UUID): String {
        val s = u.toString()
        if (s.startsWith("0000") && s.endsWith(btBase)) {
            val short = s.substring(4, 8)
            return known[short]?.let { "($it)" } ?: ""
        }
        return ""
    }

    private fun props(p: Int): String {
        val l = mutableListOf<String>()
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) l.add("read")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) l.add("write")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) l.add("writeNoResp")
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) l.add("notify")
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) l.add("indicate")
        return l.joinToString(",")
    }

    // ---------- permissions ----------
    private fun requestBlePerms() {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_FINE_LOCATION)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        blePermLauncher.launch(perms)
    }

    private fun hasBlePerms(): Boolean {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_FINE_LOCATION)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun requestHc() {
        val st = HealthConnectClient.getSdkStatus(this)
        if (st != HealthConnectClient.SDK_AVAILABLE) {
            log("Health Connect NOT available on this phone (status $st). Install/enable Health Connect.")
            return
        }
        hcLauncher.launch(hcPerms)
    }

    // ---------- scanning ----------
    private fun addDevice(d: BluetoothDevice, name: String, tag: String) {
        if (devices.put(d.address, d) == null) {
            deviceBox.addView(btn("$tag$name\n${d.address}") { connect(d) })
        }
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = d.name ?: result.scanRecord?.deviceName ?: "(no name)"
            addDevice(d, name, "[scan ${result.rssi} dBm] ")
        }

        override fun onScanFailed(errorCode: Int) {
            log("Scan failed: $errorCode")
            scanning = false
        }
    }

    private fun startScan() {
        if (!hasBlePerms()) { log("Grant Bluetooth permission first (step 1)"); return }
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { log("Turn Bluetooth on"); return }
        if (scanning) return
        deviceBox.removeAllViews()
        devices.clear()
        scanning = true
        val mgr = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        for (d in adapter.bondedDevices) addDevice(d, d.name ?: "(no name)", "[paired] ")
        for (d in mgr.getConnectedDevices(BluetoothProfile.GATT)) addDevice(d, d.name ?: "(no name)", "[connected] ")
        log("Paired: ${adapter.bondedDevices.size}, GATT-connected: ${mgr.getConnectedDevices(BluetoothProfile.GATT).size}")
        val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        log("Location switch on: ${lm.isLocationEnabled}")
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        adapter.bluetoothLeScanner?.startScan(null, settings, scanCb) ?: log("No BLE scanner available")
        log("Scanning... tap your watch when it appears (look for Reflex / Fastrack). Location switch must be ON.")
        ui.postDelayed({ stopScan() }, 15000)
    }

    private fun stopScan() {
        if (!scanning) return
        scanning = false
        try {
            (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
                .adapter.bluetoothLeScanner.stopScan(scanCb)
        } catch (e: Exception) { }
        log("Scan stopped. Devices seen: ${devices.size}")
    }

    // ---------- connection ----------
    private fun connect(d: BluetoothDevice) {
        stopScan()
        disconnect()
        log("Connecting to ${d.name} ${d.address}")
        gatt = d.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private fun disconnect() {
        queue.clear()
        busy = false
        gatt?.let {
            try { it.disconnect(); it.close() } catch (e: Exception) { }
        }
        gatt = null
    }

    private fun enqueue(op: () -> Boolean) {
        queue.addLast(op)
        if (!busy) next()
    }

    private fun next() {
        val op = queue.removeFirstOrNull()
        if (op == null) { busy = false; return }
        busy = true
        val started = try { op() } catch (e: Exception) { false }
        if (!started) next()
    }

    private fun subscribe(g: BluetoothGatt, c: BluetoothGattCharacteristic): Boolean {
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(cccd) ?: return false
        val v = if (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0)
            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, v) == BluetoothStatusCodes.SUCCESS
        } else {
            d.value = v
            g.writeDescriptor(d)
        }
    }

    private fun dumpServices(g: BluetoothGatt) {
        queue.clear()
        busy = false
        for (s in g.services) {
            log("SERVICE ${s.uuid} ${label(s.uuid)}")
            for (c in s.characteristics) {
                log("  CHAR ${c.uuid} ${label(c.uuid)} [${props(c.properties)}]")
                if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                    enqueue { g.readCharacteristic(c) }
                }
                if (c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or
                            BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                    enqueue { subscribe(g, c) }
                }
            }
        }
        enqueue {
            log("Setup done. Starting sync automatically...")
            ui.postDelayed({ syncNow() }, 800)
            false
        }
    }

    private fun handleRead(c: BluetoothGattCharacteristic, v: ByteArray, status: Int) {
        log("READ ${c.uuid} ${label(c.uuid)} status=$status = ${hex(v)}")
        next()
    }

    private fun handleChange(c: BluetoothGattCharacteristic, v: ByteArray) {
        log("NOTIFY ${c.uuid} ${label(c.uuid)} = ${hex(v)}")
        val us = c.uuid.toString()
        if (us.startsWith("00000af2")) healthCh.trySend(v)
        if (us.startsWith("00000af7")) commCh.trySend(v)
        if (c.uuid.toString().startsWith("00002a37") && v.size >= 2) {
            val flags = v[0].toInt() and 0xff
            val bpm = if ((flags and 1) == 0) v[1].toInt() and 0xff
            else (v[1].toInt() and 0xff) or ((v[2].toInt() and 0xff) shl 8)
            if (bpm in 30..230) {
                hrSamples.add(HeartRateRecord.Sample(Instant.now(), bpm.toLong()))
                log("  -> heart rate $bpm bpm (buffered: ${hrSamples.size})")
            }
        }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            log("Connection state=$newState status=$status")
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                ui.post { g.discoverServices() }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                ui.post { try { g.close() } catch (e: Exception) { } }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            log("Services discovered status=$status")
            ui.post { dumpServices(g) }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            log("Subscribed ${d.characteristic.uuid} status=$status")
            ui.post { next() }
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int
        ) {
            ui.post { handleRead(c, value, status) }
        }

        @Deprecated("old API")
        override fun onCharacteristicRead(
            g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int
        ) {
            if (Build.VERSION.SDK_INT < 33) {
                val v = c.value ?: ByteArray(0)
                ui.post { handleRead(c, v, status) }
            }
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray
        ) {
            ui.post { handleChange(c, value) }
        }

        @Deprecated("old API")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) {
                val v = c.value ?: ByteArray(0)
                ui.post { handleChange(c, v) }
            }
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int
        ) {
            log("WRITE ${c.uuid} status=$status")
            writeCh.trySend(status)
        }
    }

    private fun writeHex() {
        val g = gatt ?: run { log("Not connected"); return }
        try {
            var u = uuidIn.text.toString().trim().lowercase(Locale.US)
            if (u.length == 4) u = "0000$u$btBase"
            val uuid = UUID.fromString(u)
            val bytes = hexIn.text.toString().trim().split(Regex("[\\s,]+"))
                .filter { it.isNotEmpty() }.map { it.toInt(16).toByte() }.toByteArray()
            val c = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == uuid }
                ?: run { log("Characteristic not found"); return }
            val type = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            log("Writing ${hex(bytes)} to $uuid")
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, bytes, type)
            } else {
                c.writeType = type
                c.value = bytes
                g.writeCharacteristic(c)
            }
        } catch (e: Exception) {
            log("Write error: $e")
        }
    }

    // ---------- Reflex 3 protocol (decoded from the official app) ----------
    // All multi-byte numbers from the watch are little-endian.
    private fun u8(b: ByteArray, i: Int) = b[i].toInt() and 0xff
    private fun le16(b: ByteArray, i: Int) = u8(b, i) or (u8(b, i + 1) shl 8)
    private fun le32(b: ByteArray, i: Int): Long =
        u8(b, i).toLong() or (u8(b, i + 1).toLong() shl 8) or
            (u8(b, i + 2).toLong() shl 16) or (u8(b, i + 3).toLong() shl 24)

    private fun rawYear(h: ByteArray) = if (h.size >= 8) le16(h, 4) else 0

    private fun dayOf(h: ByteArray): LocalDate? {
        if (h.size < 8) return null
        val y = le16(h, 4)
        val m = u8(h, 6)
        val d = u8(h, 7)
        return try {
            if (y in 2020..2100 && m in 1..12 && d in 1..31) LocalDate.of(y, m, d) else null
        } catch (e: Exception) { null }
    }

    private fun payload(pk: List<ByteArray>): ByteArray {
        val o = java.io.ByteArrayOutputStream()
        for (i in 2 until pk.size) {
            val p = pk[i]
            if (p.size < 4) continue
            val len = minOf(u8(p, 3), p.size - 4)
            if (len > 0) o.write(p, 4, len)
        }
        return o.toByteArray()
    }

    private fun meta(id: String) =
        Metadata(clientRecordId = id, clientRecordVersion = System.currentTimeMillis())

    private fun hc() = HealthConnectClient.getOrCreate(this)

    private suspend fun writeChar(short: String, data: ByteArray): Boolean {
        val g = gatt ?: return false
        val uuid = UUID.fromString("0000$short$btBase")
        val c = g.services.flatMap { it.characteristics }.firstOrNull { it.uuid == uuid }
        if (c == null) { log("Characteristic $short not found"); return false }
        while (writeCh.tryReceive().isSuccess) { }
        log("TX $short ${hex(data)}")
        val started = if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) ==
                BluetoothStatusCodes.SUCCESS
        } else {
            c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            c.value = data
            g.writeCharacteristic(c)
        }
        if (!started) { log("Write did not start"); return false }
        if (withTimeoutOrNull(3000) { writeCh.receive() } == null) log("Write confirmation timeout")
        return true
    }

    // total packet count is stored in the first packet of each record
    private fun expectedPackets(type: Int, h1: ByteArray): Int =
        if (h1.size < 14) -1 else if (type == 3 || type == 5) u8(h1, 12) else u8(h1, 13)

    // returns: null = incomplete (do not save), empty = no data, otherwise packets in order
    private suspend fun fetch(type: Int): List<ByteArray>? {
        while (healthCh.tryReceive().isSuccess) { }
        if (!writeChar("0af1", byteArrayOf(8, type.toByte(), 1, 0))) return null
        val got = java.util.TreeMap<Int, ByteArray>()
        var expected = -1
        var retries = 0
        while (true) {
            val p = withTimeoutOrNull(2500) { healthCh.receive() }
            if (p == null) {
                if (expected > 0 && got.size < expected && retries < 4) {
                    retries++
                    val missing = (1..expected).filter { !got.containsKey(it) }
                    log("type $type: ${missing.size} packets missing, asking again (try $retries)")
                    for (m in missing.take(30)) {
                        writeChar("0af1", byteArrayOf(8, type.toByte(), 3, m.toByte()))
                    }
                    continue
                }
                break
            }
            if (p.size < 3 || u8(p, 0) != 8) continue
            val t = u8(p, 1)
            if (t == 0xEE) {
                if (expected <= 0 || got.size >= expected) break
                continue
            }
            if (t != type) continue
            got[u8(p, 2)] = p
            if (u8(p, 2) == 1) expected = expectedPackets(type, p)
            if (expected > 0 && got.size >= expected) {
                // let the end marker arrive so it cannot leak into the next request
                withTimeoutOrNull(800) {
                    while (true) {
                        val q = healthCh.receive()
                        if (q.size > 1 && u8(q, 1) == 0xEE) break
                    }
                }
                break
            }
        }
        if (got.isEmpty()) return emptyList()
        if (expected > 0 && got.size < expected) {
            log("type $type incomplete: ${got.size} of $expected packets")
            return null
        }
        return got.values.toList()
    }

    private suspend fun ack(type: Int, history: Boolean) {
        val b = if (history && (type == 5 || type == 8)) byteArrayOf(8, type.toByte(), 2)
        else byteArrayOf(8, type.toByte(), 2, 0)
        writeChar("0af1", b)
    }

    private suspend fun saveSteps(pk: List<ByteArray>): LocalDate? {
        if (pk.size < 2 || pk[0].size < 13 || pk[1].size < 20) { log("steps: unexpected packets"); return null }
        val day = dayOf(pk[0]) ?: run { log("steps: record has no valid date (year ${rawYear(pk[0])})"); return null }
        val steps = le32(pk[1], 4)
        val cal = le32(pk[1], 8)
        val dist = le32(pk[1], 12)
        val act = le32(pk[1], 16)
        log("STEPS $day steps=$steps calories(raw)=$cal distance(raw)=$dist active(raw)=$act")
        val zone = ZoneId.systemDefault()
        val start = day.atStartOfDay(zone).toInstant()
        val end = if (day == LocalDate.now(zone)) Instant.now()
        else day.plusDays(1).atStartOfDay(zone).toInstant()
        if (!end.isAfter(start.plusSeconds(60))) return day
        val so = zone.rules.getOffset(start)
        val eo = zone.rules.getOffset(end)
        val recs = ArrayList<Record>()
        if (steps in 1..200000) {
            recs.add(StepsRecord(startTime = start, startZoneOffset = so, endTime = end,
                endZoneOffset = eo, count = steps, metadata = meta("reflex-steps-$day")))
        }
        val kcal = if (cal > 30000) cal / 1000.0 else cal.toDouble()
        if (kcal > 0 && kcal < 20000) {
            recs.add(TotalCaloriesBurnedRecord(startTime = start, startZoneOffset = so, endTime = end,
                endZoneOffset = eo, energy = Energy.kilocalories(kcal), metadata = meta("reflex-cal-$day")))
        }
        if (recs.isNotEmpty()) hc().insertRecords(recs)
        log("Wrote $day to Health Connect: $steps steps, ${kcal.toInt()} kcal")
        return day
    }

    private suspend fun saveHr(pk: List<ByteArray>): LocalDate? {
        if (pk.size < 2 || pk[0].size < 14) { log("hr: unexpected packets"); return null }
        val day = dayOf(pk[0]) ?: run { log("hr: record has no valid date (year ${rawYear(pk[0])})"); return null }
        val offset = le16(pk[0], 8)
        val count = le16(pk[0], 11)
        val data = payload(pk)
        val zone = ZoneId.systemDefault()
        val limit = Instant.now().plusSeconds(300)
        var t = day.atStartOfDay(zone).toInstant().plusSeconds(offset * 60L)
        val samples = ArrayList<HeartRateRecord.Sample>()
        var i = 0
        while (i + 1 < data.size) {
            t = t.plusSeconds(u8(data, i) * 60L)
            val bpm = u8(data, i + 1)
            if (bpm in 30..230 && t.isBefore(limit)) samples.add(HeartRateRecord.Sample(t, bpm.toLong()))
            i += 2
        }
        log("HR $day: watch says $count readings, usable ${samples.size}")
        if (samples.isEmpty()) return day
        val st = samples.first().time
        val en = samples.last().time.plusSeconds(1)
        hc().insertRecords(listOf(HeartRateRecord(startTime = st, startZoneOffset = zone.rules.getOffset(st),
            endTime = en, endZoneOffset = zone.rules.getOffset(en), samples = samples,
            metadata = meta("reflex-hr-$day"))))
        log("Wrote ${samples.size} heart rate readings for $day to Health Connect")
        return day
    }

    private suspend fun saveSleep(pk: List<ByteArray>): LocalDate? {
        if (pk.size < 2 || pk[0].size < 14) { log("sleep: unexpected packets"); return null }
        val day = dayOf(pk[0]) ?: run { log("sleep: no sleep record"); return null }
        val hh = u8(pk[0], 8)
        val mm = u8(pk[0], 9)
        val total = le16(pk[0], 10)
        if (hh > 23 || mm > 59 || total == 0) { log("sleep: empty record $day"); return day }
        val zone = ZoneId.systemDefault()
        val endT = day.atTime(hh, mm).atZone(zone).toInstant()
        val startT = endT.minusSeconds(total * 60L)
        val data = payload(pk)
        val stages = ArrayList<SleepSessionRecord.Stage>()
        var t = startT
        var i = 0
        while (i + 1 < data.size) {
            val type = u8(data, i)
            val dur = u8(data, i + 1)
            val e = t.plusSeconds(dur * 60L)
            val st = when (type) {
                1 -> SleepSessionRecord.STAGE_TYPE_AWAKE
                2 -> SleepSessionRecord.STAGE_TYPE_LIGHT
                3 -> SleepSessionRecord.STAGE_TYPE_DEEP
                else -> -1
            }
            if (st != -1 && dur > 0) stages.add(SleepSessionRecord.Stage(startTime = t, endTime = e, stage = st))
            t = e
            i += 2
        }
        val sessionEnd = if (t.isAfter(endT)) t else endT
        log("SLEEP $day ${startT} -> ${sessionEnd} total=${total}min stages=${stages.size}")
        hc().insertRecords(listOf(SleepSessionRecord(startTime = startT,
            startZoneOffset = zone.rules.getOffset(startT), endTime = sessionEnd,
            endZoneOffset = zone.rules.getOffset(sessionEnd), title = "Fastrack Reflex sleep",
            stages = stages, metadata = meta("reflex-sleep-$day"))))
        log("Wrote sleep session for $day to Health Connect")
        return day
    }

    // Today's data is saved but never acknowledged (the watch keeps it, so nothing can be lost).
    // Past days are acknowledged only after they were written to Health Connect.
    private suspend fun runCategory(
        name: String, today: Int, hist: Int, save: suspend (List<ByteArray>) -> LocalDate?
    ) {
        log("-- $name")
        val todayDate = LocalDate.now()
        val pk = fetch(today)
        when {
            pk == null -> log("$name: incomplete, will retry on next sync")
            pk.isEmpty() -> log("$name: watch has no data")
            else -> try { save(pk) } catch (e: Exception) { log("$name save error: $e") }
        }
        var last: LocalDate? = null
        for (n in 1..20) {
            val h = fetch(hist)
            if (h == null) { log("$name history incomplete"); break }
            if (h.isEmpty()) break
            val day = try { save(h) } catch (e: Exception) { log("$name history save error: $e"); null }
            if (day == null || day == last || !day.isBefore(todayDate)) break
            last = day
            ack(hist, true)
            delay(300)
        }
    }

    private suspend fun sendTime() {
        val c = Calendar.getInstance()
        val y = c.get(Calendar.YEAR)
        val wd = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val b = byteArrayOf(
            3, 1, (y and 0xff).toByte(), ((y shr 8) and 0xff).toByte(),
            (c.get(Calendar.MONTH) + 1).toByte(), c.get(Calendar.DAY_OF_MONTH).toByte(),
            c.get(Calendar.HOUR_OF_DAY).toByte(), c.get(Calendar.MINUTE).toByte(),
            c.get(Calendar.SECOND).toByte(), wd.toByte()
        )
        writeChar("0af6", b)
    }

    private fun syncNow() {
        if (gatt == null) { log("Connect to the watch first"); return }
        if (syncing) { log("Sync already running"); return }
        syncing = true
        lifecycleScope.launch {
            try {
                val st = HealthConnectClient.getSdkStatus(this@MainActivity)
                if (st != HealthConnectClient.SDK_AVAILABLE) {
                    log("Health Connect not available (status $st)")
                    return@launch
                }
                log("== Sync started")
                writeChar("0af1", byteArrayOf(8, 1, 1, 0))
                delay(600)
                val probe = fetch(3)
                if (probe != null && probe.isNotEmpty() && rawYear(probe[0]) < 2020) {
                    log("Watch clock is wrong, setting it to phone time")
                    sendTime()
                    delay(1500)
                }
                runCategory("steps+calories", 3, 5) { saveSteps(it) }
                runCategory("heart rate", 7, 8) { saveHr(it) }
                runCategory("sleep", 4, 6) { saveSleep(it) }
                writeChar("0af1", byteArrayOf(8, 2, 1, 0))
                delay(300)
                log("== Sync finished")
            } catch (e: Exception) {
                log("Sync error: $e")
            } finally {
                syncing = false
            }
        }
    }

    private fun setWatchTime() {
        if (gatt == null) { log("Connect to the watch first"); return }
        lifecycleScope.launch { sendTime() }
    }

    // ---------- Health Connect ----------
    private fun offsetNow(): ZoneOffset = ZoneId.systemDefault().rules.getOffset(Instant.now())

    private fun syncHr() {
        if (hrSamples.isEmpty()) { log("No heart rate samples buffered yet"); return }
        val snap = hrSamples.toList()
        val off = offsetNow()
        lifecycleScope.launch {
            try {
                val hc = HealthConnectClient.getOrCreate(this@MainActivity)
                hc.insertRecords(
                    listOf(
                        HeartRateRecord(
                            startTime = snap.first().time,
                            startZoneOffset = off,
                            endTime = snap.last().time.plusSeconds(1),
                            endZoneOffset = off,
                            samples = snap
                        )
                    )
                )
                hrSamples.clear()
                log("Wrote ${snap.size} heart rate samples to Health Connect")
            } catch (e: Exception) {
                log("Health Connect error: $e")
            }
        }
    }

    private fun testHc() {
        val off = offsetNow()
        val end = Instant.now().minusSeconds(60)
        val start = end.minusSeconds(60)
        lifecycleScope.launch {
            try {
                val hc = HealthConnectClient.getOrCreate(this@MainActivity)
                hc.insertRecords(listOf(StepsRecord(start, off, end, off, 10)))
                log("Test: wrote 10 steps. Open Samsung Health > Steps to see if it shows up.")
            } catch (e: Exception) {
                log("Health Connect error: $e")
            }
        }
    }
}
